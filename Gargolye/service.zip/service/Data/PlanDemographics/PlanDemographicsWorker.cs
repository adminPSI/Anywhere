﻿namespace Anywhere.service.Data.PlanDemographics
{
    public class PlanDemographicsWorker
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace Anywhere.service.Data.PlanServicesAndSupports
{
    public class reorderSQLWorker
    {
        JavaScriptSerializer js = new JavaScriptSerializer();
        ServicesAndSupportsDataGetter dg = new ServicesAndSupportsDataGetter();

    }
}